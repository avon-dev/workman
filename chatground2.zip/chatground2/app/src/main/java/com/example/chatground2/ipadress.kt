package com.example.chatground2

object ipadress {
    const val ipadress = "http://192.168.0.3:3000/"
}
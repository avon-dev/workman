package com.example.chatground2.model

data class chatitemdata(val type:String,val data:String,val email:String, val nickname:String,val content:String,val date:String)